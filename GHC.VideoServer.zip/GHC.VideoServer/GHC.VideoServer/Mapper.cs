﻿using GHC.VideoServer.Model;

namespace GHC.VideoServer
{
    public class Mapper
    {
        private Context _context;

        public Mapper(Context context)
        {
            this._context = context;
        }
    }
}