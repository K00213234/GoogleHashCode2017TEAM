namespace GHC.VideoServer.Model
{
    public class Video
    {
        public int VideoID { get; set; }

        public int VideoSizeInMb { get; set; }
    }
}